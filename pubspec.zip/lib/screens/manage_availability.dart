
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

const Color availabilityBlue = Color(0xFF2563EB);
const Color availabilityDarkBlue = Color(0xFF172554);
const Color availabilityBackground = Color(0xFFF4F7FC);

class ManageAvailabilityPage extends StatefulWidget {
  const ManageAvailabilityPage({super.key});

  @override
  State<ManageAvailabilityPage> createState() =>
      _ManageAvailabilityPageState();
}

class _ManageAvailabilityPageState
    extends State<ManageAvailabilityPage> {
  DateTime _selectedDate =
      DateTime.now().add(const Duration(days: 1));

  TimeOfDay _startTime = const TimeOfDay(hour: 9, minute: 0);
  TimeOfDay _endTime = const TimeOfDay(hour: 10, minute: 0);

  bool _isSaving = false;

  final User? _user = FirebaseAuth.instance.currentUser;

  DateTime _combineDateAndTime(
    DateTime date,
    TimeOfDay time,
  ) {
    return DateTime(
      date.year,
      date.month,
      date.day,
      time.hour,
      time.minute,
    );
  }

  void _showMessage(
    String message, {
    bool isError = false,
  }) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor:
              isError ? Colors.red.shade700 : Colors.green.shade700,
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  Future<void> _chooseDate() async {
    final now = DateTime.now();

    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate.isBefore(
        DateTime(now.year, now.month, now.day),
      )
          ? now
          : _selectedDate,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: now.add(const Duration(days: 365)),
      helpText: 'Select consultation date',
    );

    if (picked != null && mounted) {
      setState(() {
        _selectedDate = DateTime(
          picked.year,
          picked.month,
          picked.day,
        );
      });
    }
  }

  Future<void> _chooseTime({required bool isStart}) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: isStart ? _startTime : _endTime,
      helpText: isStart
          ? 'Select start time'
          : 'Select end time',
    );

    if (picked != null && mounted) {
      setState(() {
        if (isStart) {
          _startTime = picked;
        } else {
          _endTime = picked;
        }
      });
    }
  }

  // Save a new consultation slot to Firestore.
  Future<void> _addAvailability() async {
    if (_isSaving) return;

    User? user = FirebaseAuth.instance.currentUser;

    user ??= await FirebaseAuth.instance.authStateChanges().first;

    if (user == null) {
      _showMessage(
        'Your session has expired. Please log in again.',
        isError: true,
      );
      
      if (mounted) {
        Navigator.of(context).pushNamedAndRemoveUntil(
          '/login',
          (route) => false,
        );
      }

      return;
    }

    final start = _combineDateAndTime(
      _selectedDate,
      _startTime,
    );

    final end = _combineDateAndTime(
      _selectedDate,
      _endTime,
    );

    if (!start.isAfter(DateTime.now())) {
      _showMessage(
        'The consultation start time must be in the future.',
        isError: true,
      );
      return;
    }

    if (!end.isAfter(start)) {
      _showMessage(
        'End time must be later than start time.',
        isError: true,
      );
      return;
    }

    setState(() => _isSaving = true);

    try {
      // Verify that the signed-in user is an approved lecturer.
      final profileSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();

      if (!profileSnapshot.exists) {
        _showMessage(
          'Lecturer profile not found.',
          isError: true,
        );
        return;
      }

      final profile = profileSnapshot.data();

      if (profile == null || profile['role'] != 'Lecturer') {
        _showMessage(
          'Only approved lecturers can create availability.',
          isError: true,
        );
        return;
      }

      // Check existing slots to prevent overlapping schedules.
      final existingSlots = await FirebaseFirestore.instance
          .collection('availability')
          .where('lecturerId', isEqualTo: user.uid)
          .get();

      for (final document in existingSlots.docs) {
        final data = document.data();

        if (data['startAt'] is! Timestamp ||
            data['endAt'] is! Timestamp) {
          continue;
        }

        if (data['status'] == 'cancelled') {
          continue;
        }

        final existingStart =
            (data['startAt'] as Timestamp).toDate();

        final existingEnd =
            (data['endAt'] as Timestamp).toDate();

        final overlaps =
            start.isBefore(existingEnd) &&
            end.isAfter(existingStart);

        if (overlaps) {
          _showMessage(
            'This time overlaps with an existing slot.',
            isError: true,
          );
          return;
        }
      }

      final lecturerName =
          (profile['fullName'] as String?) ??
          user.displayName ??
          'Lecturer';

      await FirebaseFirestore.instance
          .collection('availability')
          .add({
        'lecturerId': user.uid,
        'lecturerName': lecturerName,
        'startAt': Timestamp.fromDate(start),
        'endAt': Timestamp.fromDate(end),
        'status': 'available',
        'createdAt': FieldValue.serverTimestamp(),
      });

      _showMessage('Availability added successfully!');

      if (mounted) {
        setState(() {
          _selectedDate =
              DateTime.now().add(const Duration(days: 1));
          _startTime = const TimeOfDay(hour: 9, minute: 0);
          _endTime = const TimeOfDay(hour: 10, minute: 0);
        });
      }
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') {
        _showMessage(
          'Permission denied. Please check your Firestore rules.',
          isError: true,
        );
      } else {
        _showMessage(
          'Unable to save availability: ${e.message ?? e.code}',
          isError: true,
        );
      }
    } catch (e) {
      _showMessage(
        'Something went wrong. Please try again.',
        isError: true,
      );
    } finally {
      if (mounted) {
        setState(() => _isSaving = false);
      }
    }
  }

  // Delete an availability slot that has not been booked.
  Future<void> _deleteAvailability(
    String documentId,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Delete availability?'),
        content: const Text(
          'Are you sure you want to delete this time slot?',
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.pop(dialogContext, true),
            style: FilledButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    try {
      await FirebaseFirestore.instance
          .collection('availability')
          .doc(documentId)
          .delete();

      _showMessage('Availability deleted successfully.');
    } on FirebaseException catch (e) {
      _showMessage(
        e.code == 'permission-denied'
            ? 'You cannot delete this slot.'
            : 'Unable to delete availability.',
        isError: true,
      );
    }
  }

  Widget _sectionTitle(
    String title,
    String subtitle,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: availabilityDarkBlue,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          subtitle,
          style: const TextStyle(
            color: Color(0xFF64748B),
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _pickerButton({
    required String label,
    required String value,
    required IconData icon,
    required VoidCallback onPressed,
  }) {
    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        padding: const EdgeInsets.all(16),
        alignment: Alignment.centerLeft,
        side: const BorderSide(
          color: Color(0xFFE2E8F0),
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      child: Row(
        children: [
          Icon(icon, color: availabilityBlue),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: Color(0xFF64748B),
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  value,
                  style: const TextStyle(
                    color: availabilityDarkBlue,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const Icon(
            Icons.keyboard_arrow_down_rounded,
            color: Color(0xFF64748B),
          ),
        ],
      ),
    );
  }

  Widget _buildCreateForm() {
    return Card(
      color: Colors.white,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: const BorderSide(
          color: Color(0xFFE2E8F0),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(
                  Icons.add_circle_outline_rounded,
                  color: availabilityBlue,
                  size: 28,
                ),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Create Time Slot',
                    style: TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.bold,
                      color: availabilityDarkBlue,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'Choose when students can request a consultation.',
              style: TextStyle(
                color: Color(0xFF64748B),
                height: 1.5,
              ),
            ),
            const SizedBox(height: 24),

            _pickerButton(
              label: 'Consultation date',
              value: MaterialLocalizations.of(context)
                  .formatMediumDate(_selectedDate),
              icon: Icons.calendar_month_rounded,
              onPressed: _chooseDate,
            ),
            const SizedBox(height: 16),

            LayoutBuilder(
              builder: (context, constraints) {
                final startButton = _pickerButton(
                  label: 'Start time',
                  value: _startTime.format(context),
                  icon: Icons.access_time_rounded,
                  onPressed: () =>
                      _chooseTime(isStart: true),
                );

                final endButton = _pickerButton(
                  label: 'End time',
                  value: _endTime.format(context),
                  icon: Icons.schedule_rounded,
                  onPressed: () =>
                      _chooseTime(isStart: false),
                );

                if (constraints.maxWidth < 450) {
                  return Column(
                    children: [
                      startButton,
                      const SizedBox(height: 16),
                      endButton,
                    ],
                  );
                }

                return Row(
                  children: [
                    Expanded(child: startButton),
                    const SizedBox(width: 14),
                    Expanded(child: endButton),
                  ],
                );
              },
            ),

            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              height: 52,
              child: FilledButton.icon(
                onPressed: _isSaving
                    ? null
                    : _addAvailability,
                style: FilledButton.styleFrom(
                  backgroundColor: availabilityBlue,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                icon: _isSaving
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                    : const Icon(Icons.add_rounded),
                label: Text(
                  _isSaving
                      ? 'Saving availability...'
                      : 'Add Availability',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAvailabilityCard(
    QueryDocumentSnapshot<Map<String, dynamic>> document,
  ) {
    final data = document.data();

    if (data['startAt'] is! Timestamp ||
        data['endAt'] is! Timestamp) {
      return const SizedBox.shrink();
    }

    final start = (data['startAt'] as Timestamp).toDate();
    final end = (data['endAt'] as Timestamp).toDate();
    final status = data['status'] as String? ?? 'available';

    final canDelete =
        status == 'available' &&
        start.isAfter(DateTime.now());

    return Card(
      color: Colors.white,
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: const BorderSide(
          color: Color(0xFFE2E8F0),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: const Color(0xFFEFF6FF),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.event_available_rounded,
                color: availabilityBlue,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    MaterialLocalizations.of(context)
                        .formatMediumDate(start),
                    style: const TextStyle(
                      color: availabilityDarkBlue,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    '${TimeOfDay.fromDateTime(start).format(context)}'
                    ' – '
                    '${TimeOfDay.fromDateTime(end).format(context)}',
                    style: const TextStyle(
                      color: Color(0xFF475569),
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 9),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: status == 'available'
                          ? const Color(0xFFDCFCE7)
                          : const Color(0xFFFEF3C7),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      status.toUpperCase(),
                      style: TextStyle(
                        color: status == 'available'
                            ? const Color(0xFF166534)
                            : const Color(0xFF92400E),
                        fontWeight: FontWeight.bold,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (canDelete)
              IconButton(
                tooltip: 'Delete slot',
                onPressed: () =>
                    _deleteAvailability(document.id),
                icon: const Icon(
                  Icons.delete_outline_rounded,
                  color: Colors.red,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildAvailabilityList() {
    final user = _user;

    if (user == null) {
      return const Text('Please sign in to view your availability.');
    }

    return StreamBuilder<
        QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('availability')
          .where('lecturerId', isEqualTo: user.uid)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Card(
            child: Padding(
              padding: EdgeInsets.all(20),
              child: Text(
                'Unable to load availability. '
                'Please check your Firestore rules and connection.',
              ),
            ),
          );
        }

        if (snapshot.connectionState ==
            ConnectionState.waiting) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: CircularProgressIndicator(),
            ),
          );
        }

        final documents = [
          ...?snapshot.data?.docs,
        ];

        documents.sort((a, b) {
          final aValue = a.data()['startAt'];
          final bValue = b.data()['startAt'];

          final aTime = aValue is Timestamp
              ? aValue.millisecondsSinceEpoch
              : 0;

          final bTime = bValue is Timestamp
              ? bValue.millisecondsSinceEpoch
              : 0;

          return aTime.compareTo(bTime);
        });

        if (documents.isEmpty) {
          return Container(
            width: double.infinity,
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: const Color(0xFFE2E8F0),
              ),
            ),
            child: const Column(
              children: [
                Icon(
                  Icons.calendar_today_outlined,
                  size: 42,
                  color: Color(0xFF94A3B8),
                ),
                SizedBox(height: 12),
                Text(
                  'No availability yet',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: availabilityDarkBlue,
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  'Create your first consultation time slot above.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFF64748B),
                  ),
                ),
              ],
            ),
          );
        }

        return Column(
          children: documents
              .map(_buildAvailabilityCard)
              .toList(),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: availabilityBackground,
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: availabilityDarkBlue,
        elevation: 0,
        title: const Text(
          'Manage Availability',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(
              maxWidth: 900,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [
                        availabilityBlue,
                        availabilityDarkBlue,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.calendar_month_rounded,
                        color: Colors.white,
                        size: 36,
                      ),
                      SizedBox(height: 14),
                      Text(
                        'Your Consultation Schedule',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 23,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Create time slots for students to request '
                        'academic consultations with you.',
                        style: TextStyle(
                          color: Colors.white,
                          height: 1.6,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 28),

                _buildCreateForm(),

                const SizedBox(height: 30),

                _sectionTitle(
                  'My Availability',
                  'View and manage your saved consultation slots.',
                ),

                const SizedBox(height: 16),

                _buildAvailabilityList(),

                const SizedBox(height: 28),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
